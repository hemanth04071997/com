package com.virtusa.vrps.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import com.virtusa.vrps.models.AdminStatus;

public class AdminStatusDAO {
	public ArrayList<AdminStatus> getAllStatus() {
		// TODO Auto-generated method stub
		String sqlQuery = "select * from adminstatus";
		ArrayList<AdminStatus> Admin = new ArrayList<AdminStatus>();
		try (Connection con = Dbutils.buildConnection();
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sqlQuery)) {
			while (rs.next()) {
				String id = rs.getString(1);
				String status = rs.getString(2);
				String review = rs.getString(3);
				AdminStatus s = new AdminStatus(id,status,review);
				Admin.add(s);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return Admin;
	}
	public void update1(AdminStatus s) {
		String sqlQuery = "update adminstatus set status=?,review=? where employeeid=?";
		try (Connection con = Dbutils.buildConnection(); 
			 PreparedStatement pstmt = con.prepareStatement(sqlQuery)) {
			String id = s.getEmployeeid();
			String name = s.getStatus1();
			String review = s.getReview();
			pstmt.setString(1, name);
			pstmt.setString(2, review);
			pstmt.setString(3, id);
			int count = pstmt.executeUpdate();
			System.out.println(count + "record update");
		} catch (Exception e) {
			e.printStackTrace();
		}

}

}
