package com.virtusa.vrps.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.virtusa.vrps.models.Employee;

public class SearchDAO {
	public Employee getByIdentity(String email) {
		// TODO Auto-generated method stub
		String sqlQuery = "select * from Applicationtable2 where email = ?";
		Employee s = null;
		try (Connection con = Dbutils.buildConnection();
				PreparedStatement pstmt = con.prepareStatement(sqlQuery)) {
			pstmt.setString(1, email);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				int sid = rs.getInt(1);
				String name = rs.getString(2);
				String username = rs.getString(3);
				String password = rs.getString(4);
				String semail = rs.getString(5);
				String mobileNumber = rs.getString(6);
				String address = rs.getString(7);
				int roleid = rs.getInt(8);
				s = new Employee(sid, name, username, password,semail,mobileNumber, address,roleid);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}
	public Employee getByUserName(String username) {
		// TODO Auto-generated method stub
		String sqlQuery = "select * from EmployeeData where username = ?";
		Employee s = null;
		try (Connection con = Dbutils.buildConnection(); PreparedStatement pstmt = con.prepareStatement(sqlQuery)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				int sid = rs.getInt(1);
				String name = rs.getString(2);
				String susername1 = rs.getString(3);
				String password = rs.getString(4);
				String semail = rs.getString(5);
				String mobileNumber = rs.getString(6);
				String address = rs.getString(7);
				int roleid = rs.getInt(8);
				s = new Employee(sid, name, susername1, password,semail,mobileNumber, address,roleid);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}
	public Employee getByNumber(String phone) {
		// TODO Auto-generated method stub
		String sqlQuery = "select * from EmployeeData where phone = ?";
		Employee s = null;
		try (Connection con = Dbutils.buildConnection(); PreparedStatement pstmt = con.prepareStatement(sqlQuery)) {
			pstmt.setString(1, phone);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				int sid = rs.getInt(1);
				String name = rs.getString(2);
				String username = rs.getString(3);
				String password = rs.getString(4);
				String semail = rs.getString(5);
				String mobileNumber = rs.getString(6);
				String address = rs.getString(7);
				int roleid = rs.getInt(8);
				s = new Employee(sid, name, username, password,semail,mobileNumber, address,roleid);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}
	public Employee getByName(String Name) {
		// TODO Auto-generated method stub
		String sqlQuery = "select * from EmployeeData where name = ?";
		Employee s = null;
		try (Connection con = Dbutils.buildConnection(); PreparedStatement pstmt = con.prepareStatement(sqlQuery)) {
			pstmt.setString(1, Name);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				int sid = rs.getInt(1);
				String name = rs.getString(2);
				String username = rs.getString(3);
				String password = rs.getString(4);
				String semail = rs.getString(5);
				String mobileNumber = rs.getString(6);
				String address = rs.getString(7);
				int roleid = rs.getInt(8);
				s = new Employee(sid, name, username, password,semail,mobileNumber, address,roleid);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}


}
