package com.virtusa.vrps.DAO;

import java.util.ArrayList;

import com.virtusa.vrps.models.Applied;

public class Individual1DAO 
{
	String Id;
	String firstname;
	 String lastname;
		 String Status;
		 String Id1;
			 String firstname1;
		 String lastname1;
		 String Status1;

 public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public Individual1DAO(String id, String firstname, String lastname, String status) {
		super();
		Id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		Status = status;
	}
	public void display() {
		AppliedDAO asd=new AppliedDAO();
		ArrayList <Applied> as= asd.get();	
		for(int i=0;i<as.size();i++) {
			System.out.println(as.get(i));
			
		}
	}
	public Applied actualData() 
	{
		int j=0;
		AppliedDAO asd=new AppliedDAO();
		ArrayList <Applied> as= asd.get();
		 for(int i=0;i<as.size();i++)
		 {
		 if(getId().equals(as.get(i).getId()))
		 {
		Id1 = getId();
		j++;
		 }
		 else Id1=null;
		 if(getFirstname().equals(as.get(i).getFirstname()))
		 {
		firstname1=getFirstname();
		j++;
		 }
		 else
			 firstname1=null;
		 
		
		 
		 
		 if(getLastname().equals(as.get(i).getLastname()))
		 {
		lastname1=getLastname();
		j++;
		 }
		 else
			 lastname1=null;
		 
		 
		 
		 
		 if(getStatus().equals(as.get(i).getStatus()))
		 {
		Status1=getStatus();
		j++;
		 }
		 
		 else Status1=null;
		 if(j==4)
			 break;
		 }
		 
		 return new Applied(Id1,firstname1,lastname1,Status1);
	}
		
		


}

