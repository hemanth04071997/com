package junit;

import org.junit.Assert;
import org.junit.Test;

import com.virtusa.vrps.DAO.Individual1DAO;
import com.virtusa.vrps.DAO.Individual2DAO;
import com.virtusa.vrps.models.Applied;
import com.virtusa.vrps.models.Employee;

public class EmployeeTest {

	@Test
	public void test() {
		Employee astest=new Employee(2,"kavya","8063518","kavya123","prema@gmail.com","9800135562","#10,1st street,manasagangothri,Mysuru",3);
	       Individual2DAO i=new Individual2DAO(2,"kavya","8063518","kavya123","prema@gmail.com","9800135562","#10,1st street,manasagangothri,Mysuru",3);
		 
			
			 Assert.assertEquals(astest,i.actualData());
	}

}
