package junit;



import org.junit.Assert;
import org.junit.Test;

import com.virtusa.vrps.DAO.AppliedDAO;
import com.virtusa.vrps.DAO.Individual1DAO;
import com.virtusa.vrps.DAO.IndividualDAO;
import com.virtusa.vrps.models.AdminStatus;
import com.virtusa.vrps.models.Applied;

public class AppliedTest {

	@Test
	public void test() {
		Applied astest=new Applied("8063516","mouli","annapareddy","recruited");
	       Individual1DAO i=new Individual1DAO("8063516","mouli","annapareddy","recruited");
		 
			
			 Assert.assertEquals(astest,i.actualData());
}

}
