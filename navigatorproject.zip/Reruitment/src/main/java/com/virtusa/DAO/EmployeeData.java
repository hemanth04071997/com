package com.virtusa.DAO;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class EmployeeData {

	public static void main(String[] args) {
		Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");
        SessionFactory factory = configuration.buildSessionFactory();
        Session session = HibernateSessionUtil.getSession();
        
        Employee employee = (Employee) session.get(Employee.class,1);
        if(employee != null)
            System.out.println(employee);
        
        session.close();
        factory.close();

	}

}
